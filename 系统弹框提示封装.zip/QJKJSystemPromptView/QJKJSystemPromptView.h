//
//  QJKJSystemPromptView.h
//  LYCStrategyPattern
//
//  Created by LiYouCheng on 2017/1/11.
//  Copyright © 2017年 LYC. All rights reserved.
//

// --UIAlertView ,UISheetView弹框
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

typedef void (^QJKJClickAtIndexBlock)(NSInteger buttonIndex);

@interface QJKJSystemPromptView : NSObject

/**
 UIAlertView弹框提示封装
 
 @param title 标题
 @param message 信息
 @param cancelButtonTitle 取消按钮
 @param otherButtons 其它按钮数组
 @param clickAtIndex 点击事件块 取消0 其它倒序
 */
+ (void)showAlertViewWithTitle:(NSString *)title
                       message:(NSString *)message
             cancelButtonTitle:(NSString *)cancelButtonTitle
             otherButtonTitles:(NSArray *)otherButtons
                  clickAtIndex:(QJKJClickAtIndexBlock)clickAtIndex;

/**
 UIActionSheet使用封装
 
 @param view 加载view，针对iOS8以上就不起作用
 @param title 标题
 @param cancelButtonTitle 取消按钮
 @param destructiveButton 目标按钮
 @param otherButtons 其它按钮数组
 @param clickAtIndex 点击事件块 取消0，目的1，其它倒序
 */
+ (void)showActionSheetInView:(UIView *)view
                    withTitle:(NSString *)title
            cancelButtonTitle:(NSString *)cancelButtonTitle
       destructiveButtonTitle:(NSString *)destructiveButton
            otherButtonTitles:(NSArray *)otherButtons
                 clickAtIndex:(QJKJClickAtIndexBlock)clickAtIndex;

@end
