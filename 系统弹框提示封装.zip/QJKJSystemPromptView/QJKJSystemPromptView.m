//
//  QJKJSystemPromptView.m
//  LYCStrategyPattern
//
//  Created by LiYouCheng on 2017/1/11.
//  Copyright © 2017年 LYC. All rights reserved.
//

#import "QJKJSystemPromptView.h"

#define ALERT_IOS8 ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8.0)

/**
 类方法中的对象被持有
 */
static QJKJClickAtIndexBlock _clickAtIndexBlock;

@interface QJKJSystemPromptView ()
<UIAlertViewDelegate,
UIActionSheetDelegate>

@end

@implementation QJKJSystemPromptView

/**
 UIAlertView使用封装

 @param title 标题
 @param message 信息
 @param cancelButtonTitle 取消按钮
 @param otherButtons 其它按钮数组
 @param clickAtIndex 点击事件块 取消0，其它倒序
 */
+ (void)showAlertViewWithTitle:(NSString *)title
                       message:(NSString *)message
             cancelButtonTitle:(NSString *)cancelButtonTitle
             otherButtonTitles:(NSArray *)otherButtons
                  clickAtIndex:(QJKJClickAtIndexBlock)clickAtIndex {
    _clickAtIndexBlock = [clickAtIndex copy];
    
    if (ALERT_IOS8) {
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
        // Create the actions.
        if (cancelButtonTitle) {
            UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:cancelButtonTitle style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
                _clickAtIndexBlock(0);
            }];
            [alertController addAction:cancelAction];
        }
        
        NSInteger index = 1;
        for (NSString *buttonTitle in otherButtons) {
            
            UIAlertAction *otherAction = [UIAlertAction actionWithTitle:buttonTitle style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
                _clickAtIndexBlock(index);
            }];
            [alertController addAction:otherAction];
            
            index += 1;
        }
        
        UIViewController *vc = (UIViewController *)[UIApplication sharedApplication].keyWindow.rootViewController;
        [vc presentViewController:alertController animated:YES completion:nil];
    }
    else {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title
                                                        message:message
                                                       delegate:self
                                              cancelButtonTitle:cancelButtonTitle
                                              otherButtonTitles:nil];
        
        for(NSString *buttonTitle in otherButtons) {
            [alert addButtonWithTitle:buttonTitle];
        }
        
        [alert show];
    }
    
}

/**
 UIActionSheet使用封装

 @param view 加载view，针对iOS8以上就不起作用
 @param title 标题
 @param cancelButtonTitle 取消按钮
 @param destructiveButton 目标按钮
 @param otherButtons 其它按钮数组
 @param clickAtIndex 点击事件块 取消0，目的1，其它倒序
 */
+ (void)showActionSheetInView:(UIView *)view
                    withTitle:(NSString *)title
            cancelButtonTitle:(NSString *)cancelButtonTitle
       destructiveButtonTitle:(NSString *)destructiveButton
            otherButtonTitles:(NSArray *)otherButtons
                 clickAtIndex:(QJKJClickAtIndexBlock)clickAtIndex {
    
    _clickAtIndexBlock = [clickAtIndex copy];
    
    if (ALERT_IOS8) {
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:title message:@"" preferredStyle:UIAlertControllerStyleActionSheet];
        // Create the actions.
        if (cancelButtonTitle) {
            UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:cancelButtonTitle style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
                _clickAtIndexBlock(0);
            }];
            [alertController addAction:cancelAction];
        }
        
        if (destructiveButton) {
            UIAlertAction *destructiveAction = [UIAlertAction actionWithTitle:destructiveButton style:UIAlertActionStyleDestructive handler:^(UIAlertAction *action) {
                _clickAtIndexBlock(1);
            }];
            [alertController addAction:destructiveAction];
        }
        
        
        NSInteger index = 2;
        for (NSString *buttonTitle in otherButtons) {
            
            UIAlertAction *otherAction = [UIAlertAction actionWithTitle:buttonTitle style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
                _clickAtIndexBlock(index);
            }];
            [alertController addAction:otherAction];
            
            index += 1;
        }
        
        UIViewController *vc = (UIViewController *)[UIApplication sharedApplication].keyWindow.rootViewController;
        [vc presentViewController:alertController animated:YES completion:nil];
    }
    else {
        UIActionSheet *sheet = [[UIActionSheet alloc] initWithTitle:title
                                                           delegate:[self self]
                                                  cancelButtonTitle:cancelButtonTitle
                                             destructiveButtonTitle:destructiveButton
                                                  otherButtonTitles:nil];
        
        for(NSString *buttonTitle in otherButtons) {
            [sheet addButtonWithTitle:buttonTitle];
        }
        
        [sheet showInView:view];
    }
}


#pragma mark - UIAlertViewDelegate

+ (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    
    _clickAtIndexBlock(buttonIndex);
}

+ (void)alertView:(UIAlertView*)alertView didDismissWithButtonIndex:(NSInteger) buttonIndex {
    
    _clickAtIndexBlock = nil;
}

#pragma mark - UIActionSheetDelegate

+ (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
    
    _clickAtIndexBlock(buttonIndex);
}

+ (void)actionSheet:(UIActionSheet *)actionSheet didDismissWithButtonIndex:(NSInteger)buttonIndex {
    
    _clickAtIndexBlock = nil;
}



@end
